#!/usr/bin/python

########################

from resources.lib.widgets import *

########################

if __name__ == '__main__':
    plugin.run()